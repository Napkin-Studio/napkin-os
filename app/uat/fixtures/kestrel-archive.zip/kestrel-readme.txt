Kestrel Oat archive. Nothing in here is readable by the agents.
